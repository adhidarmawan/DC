﻿using UnityEngine;
using System.Collections;

public static class GeneralManager {
	public const string FILES_LOCATION = "Resources/Prefab/Enemies";
}
