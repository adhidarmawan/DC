﻿using UnityEngine;
using System.Collections;

public class StaticParameter {

	public static int baseLv;
	public static int ghostEradicated;
	public static int stageLv;
	public static int lastScore;
	public static int highScore;

}
